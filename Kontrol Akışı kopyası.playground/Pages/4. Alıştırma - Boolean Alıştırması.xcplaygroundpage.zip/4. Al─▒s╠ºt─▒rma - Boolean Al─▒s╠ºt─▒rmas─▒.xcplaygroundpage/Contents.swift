/*:
 ## Alıştırma - Boolean Alıştırması
 
 Arkadaşlarınızla yemek yemek için bir restoran seçmekte zorlandığınızı düşünün. Siz ve bir arkadaşınız yemek seçimine fazlasıyla önem veriyorsunuz. Bu akşamki yemek için koşullarınızı önceden şu şekilde belirlediniz:
 
 - Siz pizza veya balık servis eden bir yere gitmek istiyorsunuz.
 - Arkadaşınızın gideceği yerde ise vegan seçenekleri bulunması gerekiyor.
 
 
 Diğer bir arkadaşınız, her ikinizin yemek seçimine uygun bir restoran önerisiyle çıkageliyor. Bu restoranın özellikleri aşağıdaki birkaç sabit ile belirtiliyor. Eğer restoranın özellikleri grubun yemek tercihlerine uygun ise "Hadi gidelim!" cümlesini, uygun değil ise "Başka bir restoran bulalım." cümlesini konsola yazdıracak bir if-else statementı oluşturun.

 */

let balıkServisEdiyor = true
let pizzaServisEdiyor = false
let veganSeçenekleriVar = true


/*:
 Yürüyüşe çıkıp çıkmamak arasında kararsız kaldınız. Eğer hava sıcaklığı 20 derecenin üzerinde ve yağmurlu değil ise yürüyüşe çıkmayı karar verdiniz. Boolean türünde `havaGüzel` adına sahip bir sabit oluşturun. Eğer dışarısı yürüyüş koşullarınıza uygun ise "Yürüyüşe çıkacağım!" cümlesini konsola yazdıracak bir if statementı oluşturun.
 
 */
let sıcaklık = 32
let yağmurlu = true
let güneşli = true


//: [Geri](@previous)  |  sayfa 4 /  9  |  [İleri: Uygulama - Hedef Kalp Atış Hızı](@next)
